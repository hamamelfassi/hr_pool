# XML-only addon scaffold.
